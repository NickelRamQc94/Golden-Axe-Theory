# Golden-Axe Theory

## Overview
This repository contains the complete framework for the Golden-Axe Theory, including an interactive website and a calculator for Π_N.