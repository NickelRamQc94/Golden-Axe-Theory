prochaines_actions = {
    'court_terme': [
        "Tester MENeS sur 10 matériaux réels",
        "Publier l'algorithme d'extraction",
        "Créer base de données MENeS open-source"
    ],
    'moyen_terme': [
        "Établir classification MENeS des matériaux",
        "Développer capteur MENeS portable",
        "Brevet méthode diagnostic médical"
    ],
    'long_terme': [
        "Théorie unifiée turbulence/complexité",
        "Golden-Axe dans programme scolaire",
        "Prix Nobel (pourquoi pas?)"
    ]
}